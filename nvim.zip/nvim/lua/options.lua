require "nvchad.options"

-- add yours here!
-- local o = vim.o
vim.g.python_recommended_style = 0
vim.o.expandtab = false
vim.o.tabstop = 4
vim.o.shiftwidth = 4
-- o.cursorlineopt ='both' -- to enable cursorline!
